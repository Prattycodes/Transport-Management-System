<?php
include 'connection.php';
include 'topnav.php';
?>

          <!-- Breadcrumbs-->
          <ol class="breadcrumb"
            <li class="breadcrumb-item" style="background-image: linear-gradient();">
              <a href="index."> <h2> BUS SCHEDULE SYSTEM </h2> </a>
            </li>
           
          </ol>

          <div class="bus_logo">
            <a class="image full"><img src="image/deluxe.jpg" style="width:800px;" style="background-attachment: fixed;" style="background-size: contain;"  > </a>

         <!-- Page Content -->
          <h4><h4/>
          
          <hr>
          <p> <h5> </h5></p>

<?php include 'footer.php'; ?>